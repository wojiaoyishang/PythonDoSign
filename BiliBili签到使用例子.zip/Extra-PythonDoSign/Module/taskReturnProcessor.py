"""
用于任务的结果信息的处理
"""
import Module.console as console
import Module.dingTalk as dingTalk

def main(returnInfo):
    """自动签到任务的返回值会给此函数处理，若用户于在之前将 NotNext 的值设成 True 的任务数据则不会调用此函数"""
    # 输出任务执行数据
    p = {"Success": console.success, "Failed": console.error, "Warning": console.warm, "Unknown": console.log}.get(
        returnInfo['State'], console.plain)
    p("任务信息：", returnInfo['Message'])
    p("任务细节：", returnInfo['Detail'])
    p(returnInfo['More'])

    TaskInfo = returnInfo['TaskInfo']

    console.plain("正在发送钉钉......")
    message = f"你好，以赏！您的自动签到任务 {TaskInfo['TaskName']} \n" \
              f"处于状态 {returnInfo['Message']}（{returnInfo['State']}）\n" \
              f"详情如下：\n" \
              f"{returnInfo['Detail']}\n" \
              f"{returnInfo['More']}"

    if dingTalk.send_text_message(message):
        console.success("发送钉钉成功！")
    else:
        console.error("发送钉钉失败！")
