# -*- coding:utf-8 -*-
import time
import hmac
import hashlib
import base64
import urllib.parse
import requests
import json

def send_text_message(content):
    webhook = "https://oapi.dingtalk.com/robot/send?access_token=362dc9f89c9861041cbfd16f249022421e2ee031deb396ed4369143a0bf16371"
    secret = "SECf3d3884e7a805a1ca9efb367746320800198868b0d2db8c437781ee6374cf4bf"
    timestamp = str(round(time.time() * 1000))
    secret_enc = secret.encode('utf-8')
    string_to_sign = '{}\n{}'.format(timestamp, secret)
    string_to_sign_enc = string_to_sign.encode('utf-8')
    hmac_code = hmac.new(secret_enc, string_to_sign_enc, digestmod=hashlib.sha256).digest()
    sign = urllib.parse.quote_plus(base64.b64encode(hmac_code))
    webhook += "&sign=" + sign + "&timestamp=" + timestamp

    data = {
        "text": {
            "content": content
        },
        "msgtype": "text"
    }

    return requests.post(webhook, data=json.dumps(data), headers={'Content-Type':'application/json'}).json()['errcode'] == 0

